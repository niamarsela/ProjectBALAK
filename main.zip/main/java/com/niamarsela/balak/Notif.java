package com.niamarsela.balak;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class Notif extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notif);

        TextView textView = findViewById(R.id.text_view);

        String massage = getIntent().getStringExtra("pesan dari balak");
        textView.setText(massage);
    }
}
