package com.niamarsela.balak;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class HasilGameAksara extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hasil_game_aksara);
    }
}
