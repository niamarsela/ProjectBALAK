package com.niamarsela.balak;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class Kamuss extends AppCompatActivity implements View.OnClickListener{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kamuss);
    }

    @Override
    public void onClick(View view) {

    }
    public void onkamusbahasa (View view) {
        Intent i= new Intent(Kamuss.this, KamusBahasa.class);
        startActivity(i);
    }
    public void ongamebahasa (View view) {
        Intent i= new Intent(Kamuss.this, GameKamus.class);
        startActivity(i);

    }
}
