package com.niamarsela.balak;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Point;
import android.graphics.Rect;
import android.view.Display;
import android.view.MotionEvent;
import android.view.View;
import android.os.Handler;

import java.util.Random;


public class Gameview extends View {

    Handler handler;
    Runnable runnable;
    final int UPDATE_MILILIS=35;
    Bitmap background;
    Bitmap toptube, bottomtube;
    Display display;
    Point point;
    int dWidth, dHeight;
    Rect rect;

    Bitmap[]ikan;
    int ikanFrame= 0;
    int velocity=0,gravity=3;
    int ikanx,ikany;
    boolean gameState = false;
    int gap = 400; //jarak antara atas dengan bawah
    int minTubeOffset, maxTubeOffset;
    int numberOfTubes= 4;
    int distanceBetweenTubes;
    int[] tubeX =new int[numberOfTubes];
    int[] topTubeY= new int [numberOfTubes];
    Random random;
    int tubeVelocity = 8;



    public Gameview(Context context){
        super(context);
        handler = new Handler();
        runnable=new Runnable() {
            @Override
            public void run() {
                invalidate();
            }
        };
        background = BitmapFactory.decodeResource(getResources(),R.drawable.background);
        toptube = BitmapFactory.decodeResource(getResources(),R.drawable.nah);
        bottomtube =  BitmapFactory.decodeResource(getResources(),R.drawable.noh);
        display = ((Activity) getContext()).getWindowManager().getDefaultDisplay();
        point = new Point();
        display.getSize(point);
        dWidth =point.x;
        dHeight=point.y;
        rect = new Rect(0,0,dWidth,dHeight);
        ikan = new Bitmap[2];
        ikan [0] = BitmapFactory.decodeResource(getResources(),R.drawable.ikankecilbener2);
        ikan[1] = BitmapFactory.decodeResource(getResources(),R.drawable.ikankecilbener1);
        ikanx =dWidth/2-ikan[0].getWidth()/2;
        ikany =dHeight/2-ikan[0].getHeight()/2;
        distanceBetweenTubes = dWidth*3/4; //asumsi saja
        minTubeOffset = gap/2;
        maxTubeOffset = dHeight - minTubeOffset - gap;
        random = new Random();
        for (int  i=0;i<numberOfTubes;i++){

            tubeX [i] = dWidth +i*distanceBetweenTubes;
            topTubeY[i] = minTubeOffset + random.nextInt(maxTubeOffset-minTubeOffset+1);
        }
    }

    protected void onDraw(Canvas canvas){
        super.onDraw(canvas);
        canvas.drawBitmap(background,null,rect,null);
        if(ikanFrame == 0) {
            ikanFrame = 1;
        }else{
            ikanFrame=0;
        }
        if (gameState) {
            if (ikany < dHeight - ikan[0].getHeight() || velocity < 0) {
                velocity += gravity;
                ikany += velocity;
            }

            for (int i=0;i<numberOfTubes;i++){
                tubeX[i]-= tubeVelocity;
                if (tubeX[i]< -toptube.getWidth()){
                    tubeX[i] += numberOfTubes * distanceBetweenTubes;
                    topTubeY[i] = minTubeOffset + random.nextInt(maxTubeOffset-minTubeOffset+1);
                }
            canvas.drawBitmap(toptube,tubeX[i],topTubeY[i]- toptube.getWidth(),null);
            canvas.drawBitmap(bottomtube,tubeX[i] ,topTubeY[i]+gap, null);
            }
        }


        canvas.drawBitmap(ikan[ikanFrame],ikanx, ikany,null);
        handler.postDelayed(runnable,UPDATE_MILILIS);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {

        int action = event.getAction();
        if (action == MotionEvent.ACTION_DOWN) {

            velocity= -30;
            gameState= true;

        }
        return true;
    }
}
