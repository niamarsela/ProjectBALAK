package com.niamarsela.balak;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Gameaksara extends AppCompatActivity {

    private EditText soal_aksara;
    private Button jawab;
    private TextView info;
    private int kesempatan=5;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gameaksara);

        soal_aksara=(EditText) findViewById(R.id.isi);
        jawab=(Button)findViewById(R.id.jawabaksara);
        info=(TextView)findViewById(R.id.kesempatan);

        info.setText("kesempatan kamu mencoba hanaya : 5");

        jawab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                validasi(soal_aksara.getText().toString());
            }
        });

    }

    private void  validasi (String benar){
        if (benar=="pak ardian ganteng"){
            Intent i=new Intent(Gameaksara.this, HasilGameAksara.class);
            startActivity(i);
        }
        else {
            kesempatan--;

            info.setText("kesempayan mencoba anda adalah " + String.valueOf(kesempatan));

            if(kesempatan==0){
                jawab.setEnabled(false);
            }
        }
    }

}
