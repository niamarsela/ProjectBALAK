package com.niamarsela.balak;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class GameloncatActivity extends  Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gameloncat);
    }

    public void startGame (View view){

        Intent intent= new Intent (this,MulaiGame.class);
        startActivity(intent);
        finish();
    }
}
