package com.niamarsela.balak;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentTransaction;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.print.PageRange;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ToggleButton;

public class MainActivity extends FragmentActivity implements View.OnClickListener {

    MediaPlayer audio;
    Button btnHome, btnAbout;
    HomeFragment home;
    About about;

    @Override
    protected void onCreate (Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnHome = (Button) findViewById(R.id.Home);
        btnAbout= (Button) findViewById(R.id.About);
        btnHome.setOnClickListener(this);
        btnAbout.setOnClickListener(this);


        audio = MediaPlayer.create(this, R.raw.cangget);
        audio.setLooping(true);
        audio.setVolume(1,1);
        audio.start();

    }
    void mHome(){
        home =new HomeFragment();
        FragmentTransaction ft=getSupportFragmentManager().beginTransaction().replace(R.id.container,home);
        ft.commit();
    }
    void mAbout(){
        about=new About();
        FragmentTransaction ft=getSupportFragmentManager().beginTransaction().replace(R.id.container,about);
        ft.commit();

    }

    @Override
    public void onClick(View v) {
        if ( v == btnHome){
            mHome();
        }
        if (v== btnAbout){
            mAbout ();
        }

    }
    public void onkamus (View view) {
        Intent i= new Intent(MainActivity.this, Kamuss.class);
        startActivity(i);
    }
    public void onAksara (View view) {
        Intent i= new Intent(MainActivity.this, AksaraActivity.class);
        startActivity(i);

    }
    public void onGameloncat (View view) {
        Intent i= new Intent(MainActivity.this, GameloncatActivity.class);
        startActivity(i);

    }
    public void menupencarian (View view) {
        Intent i= new Intent(MainActivity.this, PencarianActivity.class);
        startActivity(i);

    }

    public void OnToggleClicked (View view){

        boolean on=((ToggleButton) view).isChecked();

        if (on){
            audio.setVolume(0,0);
        }else {
            audio.setVolume(1,1);
        }
    }
    public void OnBackPresed (View view) {
        audio.stop();
        MainActivity.this.finish();
    }
}
