package com.niamarsela.balak;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class GameKamus extends Activity {

    TextView Soal;
    RadioGroup R1;
    RadioButton P1, P2, P3, P4;
    int noomor = 0;
    public static int hasil, benar, salah;


    String[] gamekamus = new String[]{
            "1. Guwai pandai ulun seunyin ni ",
            "2. Mak ngedok sai sikop dilom kelas hinji",
            "3. Siapa gawoh sai cocok guwai jadi muli-mekhanai",
            "4. Anah kidah makkung lapah ghadu palai Semboyan anjak sanak ? "
    };

    //jawaban
    String[] jawaban = new String[]{
            "Mengetahui apa yang sedang terjadi", "Menaruh kepercayaan kepada kalian", "Membuat pintar seluruh orang", "Membuat sesuatu hal yang baru",
            "Nayah", "Cutik", "Bela", "Nduh kidah",
            "Rifki kurniawan-Cahyani Ramadhani", "Yimyam-Cahyani Ramadhani", "Puying-Cahyani Ramadhani", "anah kidah benor seunyinni YAY !",
            "malas", "lawang", "pandai", "santuyy",
    };

    String[] Jawaban_benar = new String[]{
            "Membuat pintar seluruh orang",
            "Nayah",
            "anah kidah benor seunyinni YAY !",
            "santuyy",
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_kamus);

        Soal = (TextView) findViewById(R.id.soaltampil);
        R1 = (RadioGroup) findViewById(R.id.r1);
        P1 = (RadioButton) findViewById(R.id.a1);
        P2 = (RadioButton) findViewById(R.id.b1);
        P3 = (RadioButton) findViewById(R.id.c1);
        P4 = (RadioButton) findViewById(R.id.d1);

        Soal.setText(gamekamus[noomor]);
        P1.setText(jawaban[0]);
        P2.setText(jawaban[1]);
        P3.setText(jawaban[2]);
        P4.setText(jawaban[3]);

        R1.check(0);
        benar = 0;
        salah = 0;
    }

    public void next(View view) {
        if (P1.isChecked() || P2.isChecked() || P3.isChecked() || P4.isChecked()) {
            RadioButton jawaban_user = (RadioButton) findViewById(R1.getCheckedRadioButtonId());
            String ambil_jawaban_user = jawaban_user.getText().toString();
            R1.check(0);
            if (ambil_jawaban_user.equalsIgnoreCase(Jawaban_benar[noomor])) benar++;
            noomor++;
            if (noomor < gamekamus.length) {
                Soal.setText(gamekamus[noomor]);
                P1.setText(jawaban[(noomor * 4) + 0]);
                P2.setText(jawaban[(noomor * 4) + 1]);
                P3.setText(jawaban[(noomor * 4) + 2]);
                P4.setText(jawaban[(noomor * 4) + 3]);

            } else {
                hasil = benar * 25;
                Intent selesai = new Intent(getApplicationContext(), HasilGameKamus.class);
                startActivity(selesai);
            }
            salah=4-benar;
        }
        else{
            Toast.makeText(this,"tolong disi kudo ", Toast.LENGTH_SHORT).show();
        }
    }
}