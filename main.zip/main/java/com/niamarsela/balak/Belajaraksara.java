package com.niamarsela.balak;

import androidx.appcompat.app.AppCompatActivity;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Belajaraksara extends AppCompatActivity {
    Button Ka,Ga,Nga,Pa,Ba,Ma,Ta,Da,Na,Ca,Ja,Nya,Ya,AA,La,Ra,Sa,Wa,Ha,Gha;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_belajaraksara);

        Ka = (Button) findViewById((R.id.ka));
        final MediaPlayer mp=MediaPlayer.create(this,R.raw.hurufka);

        Ga= (Button) findViewById((R.id.ga));
        final MediaPlayer GA=MediaPlayer.create(this,R.raw.hurufga);

        Nga= (Button) findViewById((R.id.nga));
        final MediaPlayer NGA=MediaPlayer.create(this,R.raw.hurufnga);

        Pa= (Button) findViewById((R.id.pa));
        final MediaPlayer PA=MediaPlayer.create(this,R.raw.hurufpa);

        Ba= (Button) findViewById((R.id.ba));
        final MediaPlayer BA=MediaPlayer.create(this,R.raw.hurufba);

        Ma= (Button) findViewById((R.id.ma));
        final MediaPlayer MA=MediaPlayer.create(this,R.raw.hurufma);

        Ta = (Button) findViewById((R.id.ta));
        final MediaPlayer TA=MediaPlayer.create(this,R.raw.hurufta);

        Da = (Button) findViewById((R.id.da));
        final MediaPlayer DA=MediaPlayer.create(this,R.raw.hurufda);

        Na= (Button) findViewById((R.id.na));
        final MediaPlayer NA=MediaPlayer.create(this,R.raw.hurufna);

        Ca= (Button) findViewById((R.id.ca));
        final MediaPlayer CA=MediaPlayer.create(this,R.raw.hurufca);

        Ja= (Button) findViewById((R.id.ja));
        final MediaPlayer JA=MediaPlayer.create(this,R.raw.hurufja);

        Nya= (Button) findViewById((R.id.nya));
        final MediaPlayer NYA=MediaPlayer.create(this,R.raw.hurufnya);

        Ya= (Button) findViewById((R.id.ya));
        final MediaPlayer YA=MediaPlayer.create(this,R.raw.hurufya);

        AA = (Button) findViewById((R.id.a));
        final MediaPlayer A=MediaPlayer.create(this,R.raw.hurufa);

        La = (Button) findViewById((R.id.la));
        final MediaPlayer LA=MediaPlayer.create(this,R.raw.hurufla);

        Ra= (Button) findViewById((R.id.ra));
        final MediaPlayer RA=MediaPlayer.create(this,R.raw.hururra);

        Sa= (Button) findViewById((R.id.sa));
        final MediaPlayer SA=MediaPlayer.create(this,R.raw.hurufsa);

        Wa= (Button) findViewById((R.id.wa));
        final MediaPlayer WA=MediaPlayer.create(this,R.raw.hurufwa);

        Ha= (Button) findViewById((R.id.ha));
        final MediaPlayer HA=MediaPlayer.create(this,R.raw.hurufha);

        Gha= (Button) findViewById((R.id.gha));
        final MediaPlayer GHA=MediaPlayer.create(this,R.raw.hurufgha);






        Ka.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                mp .start();
            }
        });

        Ga.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                GA .start();
            }
        });

        Nga.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                NGA .start();
            }
        });

        Pa.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                PA .start();
            }
        });

        Ba.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                BA.start();
            }
        });

        Ma.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                MA .start();
            }
        });

        Ta.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                TA .start();
            }
        });

        Da.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                DA .start();
            }
        });

        Na.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                NA .start();
            }
        });

        Ca.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                CA .start();
            }
        });

        Nya.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                NYA .start();
            }
        });

        Ya.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                YA.start();
            }
        });

        AA.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                A .start();
            }
        });

        La.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                LA .start();
            }
        });

        Ra.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                RA .start();
            }
        });

        Sa.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                SA .start();
            }
        });

        Wa.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                WA .start();
            }
        });

        Ha.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                HA .start();
            }
        });

        Gha.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                GHA .start();
            }
        });
    }
}
