package com.niamarsela.balak;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class AksaraActivity extends AppCompatActivity implements View.OnClickListener{


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_aksara);
    }

    @Override
    public void onClick(View view) {

    }
    public void onbelajaraksara (View view) {
        Intent i= new Intent(AksaraActivity.this, Belajaraksara.class);
        startActivity(i);
    }
    public void ongameaksara (View view) {
        Intent i= new Intent(AksaraActivity.this, GameAksaraReal.class);
        startActivity(i);

    }

}
