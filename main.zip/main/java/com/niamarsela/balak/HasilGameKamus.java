package com.niamarsela.balak;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class HasilGameKamus extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hasil_game_kamus);

        TextView hasil=(TextView) findViewById(R.id.hasilgameaksara);
        TextView nilai=(TextView) findViewById(R.id.nilaigameaksara);

        hasil.setText("Jawaban Benar : "+GameKamus.benar+"\nJawaban salah : "+GameKamus.salah );
        nilai.setText(""+GameKamus.hasil);
    }

    public void ulangi(View view){
        finish();
        Intent i= new Intent(getApplicationContext(),GameKamus.class);
        startActivity(i);

    }
}
