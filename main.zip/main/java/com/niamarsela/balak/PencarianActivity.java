package com.niamarsela.balak;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.SearchView;

import java.util.ArrayList;
import java.util.Arrays;

public class PencarianActivity extends AppCompatActivity {

    ListView listView;
    ArrayAdapter <String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pencarian);

        listView= (ListView) findViewById(R.id.list_pencarian);

        ArrayList<String> arraycari = new ArrayList<>();
        arraycari.addAll(Arrays.asList(getResources().getStringArray(R.array.kamus)));

        adapter = new ArrayAdapter<>(
                PencarianActivity.this,
                android.R.layout.simple_list_item_1,
                arraycari
        );
        listView.setAdapter(adapter);
    }

    @Override
    public boolean onCreateOptionsMenu(@NonNull Menu menu) {
        super.onCreateOptionsMenu(menu);
        MenuInflater Inflater = getMenuInflater();
        Inflater.inflate(R.menu.search_menu, menu);
        MenuItem item=menu.findItem(R.id.list_pencarian);
        SearchView searchView = (SearchView)item.getActionView();

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String s) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String s) {
                adapter.getFilter().filter(s);
                return false;
            }
        });

        return super.onCreateOptionsMenu(menu);
    }
}
