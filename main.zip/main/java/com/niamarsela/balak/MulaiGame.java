package com.niamarsela.balak;

import android.app.Activity;
import android.os.Bundle;

import androidx.annotation.Nullable;

public class MulaiGame extends Activity {

    Gameview gameview;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        gameview =  new Gameview(this);
        setContentView(gameview);

    }
}

