package com.niamarsela.balak;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class KamusBahasa extends AppCompatActivity {
    Spinner spinner, AwalanB, AwalanC, AwalanD, AwalanE, AwalanF, AwalanG, AwalanH, AwalanI, AwalanJ;
    TextView textview;
    String[] kamus;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kamus_bahasa);

        spinner = (Spinner) findViewById(R.id.spinner);
        textview = (TextView) findViewById(R.id.Tampilan);
        kamus = getResources().getStringArray(R.array.kamus);
        spinner.setPrompt("Pilih arti");
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View v, int position, long id) {

                textview.setText("anda memilih : " + kamus[position]);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
            }
        });
    }

    public void pindahnotifikasi (View view) {
        Intent i= new Intent(KamusBahasa.this, NotificationExample.class);
        startActivity(i);

    }
}
