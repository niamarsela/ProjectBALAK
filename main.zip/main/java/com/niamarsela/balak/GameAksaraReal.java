package com.niamarsela.balak;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.util.ArrayList;

public class GameAksaraReal extends AppCompatActivity {

    TextView questionLabel,questionCountLabel,scoreLabel;
    EditText answerEdit;
    Button submitButton;
    ProgressBar progressBar;
    ArrayList<QuestionModel>questionModelArrayList;


    int currentPosition=0;
    int numberOfCorrectAnswer=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_aksara_real);

        questionCountLabel =  findViewById(R.id.noQuestion);
        questionLabel = findViewById(R.id.question);
        scoreLabel = findViewById(R.id.score);

        answerEdit= findViewById(R.id.answer);
        submitButton = findViewById(R.id.submit);
        progressBar = findViewById(R.id.progres);

        questionModelArrayList = new ArrayList<>();

        setUpQuestion();
        setData();
        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CheckAnswer();

            }
        });


    }

    public void CheckAnswer (){
        String answerString= answerEdit.getText().toString().trim();

        if (answerString.equalsIgnoreCase(questionModelArrayList.get(currentPosition+1).getAnswer())){
            numberOfCorrectAnswer ++;
            Log.e("jawaban","benar");
            currentPosition ++;
            setData();
            answerEdit.setText("");

        }else{
            Log.e("jawaban","salah");
            currentPosition ++;
            setData();
            answerEdit.setText("");
        }

        int x = ((currentPosition)+=1) / questionModelArrayList.size();
        progressBar.setProgress(x);

    }


    public void setUpQuestion (){

        questionModelArrayList.add(new QuestionModel("huruf yang tidak boleh di beri tanda mati","6"));
        questionModelArrayList.add(new QuestionModel("berapa jumlah anak huruf ?","12"));
        questionModelArrayList.add(new QuestionModel("berapa jumlah huruf aksara  ?","20"));
        questionModelArrayList.add(new QuestionModel("apa singkatan dari balak ?","81"));
        questionModelArrayList.add(new QuestionModel("apa 4*4","16"));


    }
    public void setData(){

        questionLabel.setText(questionModelArrayList.get(currentPosition).getQuestionString());
        questionCountLabel.setText(("pertanyaan nomor : " + currentPosition+1));
        scoreLabel.setText("Nilai : " + numberOfCorrectAnswer + "/" + questionModelArrayList.size()) ;

    }
}
